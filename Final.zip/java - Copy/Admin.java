import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.JPasswordField.*;

public class Admin extends JFrame implements ActionListener{
    JPanel MainP, UserP, ShopP, BorderP;
    JLabel TitleL, UserL, ShopL;
    JButton UserB, ShopB, BackB;
    ImageIcon UserImg, ShopImg;

    Font font40 = new Font("Candara",Font.BOLD,40);
    Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16); 

    public Admin() {

        super(" Admin Panel");
        this.setSize(1188, 850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null); 
        ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
     
        // MAIN PANEL...................
		MainP = new JPanel();
		MainP.setBounds(0,0,1188,850);
		MainP.setLayout(null);
		MainP.setBackground(new Color(204, 202, 202));
		this.add(MainP);
	
	    UserImg = new ImageIcon(new ImageIcon("User.JPG").getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH));
        ShopImg = new ImageIcon(new ImageIcon("Shop.JPG").getImage().getScaledInstance(300, 200, Image.SCALE_SMOOTH));

        TitleL = new JLabel("Admin Panel");
        TitleL.setFont(font40);
        TitleL.setForeground(Color.black);
        TitleL.setBounds(480, 100, 350,50);
        MainP.add(TitleL);

        UserB = new JButton(UserImg);
        UserB.setBounds(200, 280, 300, 200);
        UserB.addActionListener(this);
        MainP.add(UserB);

        ShopB = new JButton(ShopImg);
        ShopB.setBounds(688, 280, 300, 200);
        ShopB.addActionListener(this);
        MainP.add(ShopB);

        BackB = new JButton(" Back ");
		BackB.setBounds(50,700,120,30);
        BackB.setFont(font16);
		BackB.setBackground(Color.GRAY);
		BackB.addActionListener(this);
		MainP.add(BackB);



    }
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == UserB){
            UserInformation ui = new UserInformation();
            this.setVisible(false);
            ui.setVisible(true);

        }
        else if (ae.getSource() == ShopB){
            ShopManagerInformation smi = new ShopManagerInformation();
            this.setVisible(false);
           // smi.setVisible
        }
        else if(ae.getSource()== BackB)
			{
				UserLogin f = new UserLogin();
				this.setVisible(false);
				f.setVisible(true);
			}

    }
}

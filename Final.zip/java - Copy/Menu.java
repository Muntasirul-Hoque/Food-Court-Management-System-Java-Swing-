import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.JPasswordField.*;

public class Menu extends JFrame implements ActionListener {
	JPanel p1,p11,p2,p22,p3,p33,p4,p44,p5,p55,p6,p66,p7,p77,p8,p88,p9,p99,p0,p00, ft1,ft2,ft3, ff,drn,dsrt, MainP,profile,food,cart,btn, prfP1,prfP2,prfP3;
	JLabel foodL1,foodL11,foodL2,foodL22,foodL3,foodL33,foodL4,foodL44,foodL5,foodL55,foodL6,foodL66,foodL7,foodL77,foodL8,foodL88,foodL9,foodL99,foodL0,foodL00;
	JLabel prL1,prL11,prL2,prL22,prL3,prL33,prL4,prL44,prL5,prL55,prL6,prL66,prL7,prL77,prL8,prL88,prL9,prL99,prL0,prL00, discountL,totalL, offer1L,offer2L,offer3L;		
	JLabel imL1,imL2,imL3,imL4,imL5,imL6,imL7,imL8,imL9,imL0, qntL1,qntL2,qntL3,qntL4,qntL5,qntL6,qntL7,qntL8,qntL9,qntL0, ftL1,ftL2,ftL3, prfL1,nameL,addressL,phoneL;
	JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b0, profileB,discountB,clearB,doneB,payB,backB;
	JTextField totalTF,discountTF, userNameTF,nameTF,phoneTF,addressTF;
	JTextArea area;
	JSpinner s1,s2,s3,s4,s5,s6,s7,s8,s9,s0;
	ImageIcon im1,im2,im3,im4,im5,im6,im7,im8,im9,im0, impp,imicon;
	Image pizza,burger,sandwich,pasta,mojo,rc,pepsi,waffles,iceCream,cake,icon,pPic;
	int cnt=1;
	float total = 0, discount;

	Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16);
		
	public Menu() {
        //set Frame.....................
		this.setTitle("Menu");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(1188,850);
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());

        //Set all picture.......................
		impp = new ImageIcon("Profile.jpg"); // Profile pic
		pPic = impp.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		im1 =  new ImageIcon("Pizza.jpg");
		pizza = im1.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im2 =  new ImageIcon("Burger.jpg");
		burger = im2.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im3 =  new ImageIcon("Sandwich.jpg");
		sandwich = im3.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im4 =  new ImageIcon("Pasta.jpg");
		pasta = im4.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im5 =  new ImageIcon("Cake.jpg");
		cake = im5.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im6 =  new ImageIcon("Waffles.jpg");
		waffles = im6.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im7 =  new ImageIcon("IceCream.jpg");
		iceCream = im7.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im8 =  new ImageIcon("Mojo.jpg");
		mojo = im8.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im9 =  new ImageIcon("Rc.jpg");
		rc = im9.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);
		im0 =  new ImageIcon("Pepsi.jpg");
		pepsi = im0.getImage().getScaledInstance(160, 90, Image.SCALE_SMOOTH);

		// MAIN PANEL...................
		MainP = new JPanel();
		MainP.setBounds(0,0,1188,850);
		MainP.setLayout(null);
		MainP.setBackground(Color.white);
		this.add(MainP);

		profile = new JPanel();
		profile.setBounds(0,0,130,850);
		profile.setLayout(null);
		profile.setBackground(new Color(251,252,247));
		MainP.add(profile);

		food = new JPanel();
		food.setBounds(130,0,715,850);
		food.setLayout(null);
		food.setBackground(Color.black);
		MainP.add(food);

		cart = new JPanel();
		cart.setBounds(845,0,330,580);
		cart.setLayout(null);
		cart.setBackground(Color.white);
		MainP.add(cart);

		btn = new JPanel();
		btn.setBounds(845,580,330,270);
		btn.setLayout(null);
		btn.setBackground(new Color(238,238,228));
		MainP.add(btn);

		// Profile..................
		prfP1 = new JPanel();
		prfP1.setBounds(15,15,100,75);
		prfP1.setLayout(null);
		profile.add(prfP1);

		prfL1 = new JLabel();
		prfL1.setLayout(null);
		prfL1.setBounds(0,0,100,75);
		prfL1.setIcon(new ImageIcon(pPic));
		prfP1.add(prfL1);

		userNameTF = new JTextField();
		userNameTF.setBounds(15, 100, 100, 30);
		userNameTF.setText(" Alvi77");
		userNameTF.setEditable(false);
		profile.add(userNameTF);

		profileB = new JButton("Profile");
		profileB.setBounds(15, 160, 100, 30);
		profileB.setFont(font16);
		profile.add(profileB);
		
		//Food Title...................
		ft1 = new JPanel();
		ft1.setBounds(0,0,740,40);
		ft1.setLayout(null);
		ft1.setBackground(new Color(179, 179, 181));
		food.add(ft1);

		ftL1 = new JLabel("Fast Food");
		ftL1.setForeground(Color.black);
		ftL1.setFont(font25);
		ftL1.setBounds(300,5,700,40);
		ft1.add(ftL1);
		//----------------------
		ft2 = new JPanel();
		ft2.setBounds(0,270,740,40);
		ft2.setLayout(null);
		ft2.setBackground(new Color(179, 179, 181));
		food.add(ft2);

		ftL2 = new JLabel("Dessert");
		ftL2.setForeground(Color.black);
		ftL2.setFont(font25);
		ftL2.setBounds(300,5,700,40);
		ft2.add(ftL2);
			//-------------------------
		ft3 = new JPanel();
		ft3.setBounds(0,540,740,40);
		ft3.setLayout(null);
		ft3.setBackground(new Color(179, 179, 181));
		food.add(ft3);

		ftL3 = new JLabel("Soft Drinks");
		ftL3.setForeground(Color.black);
		ftL3.setFont(font25);
		ftL3.setBounds(300,5,700,40);
		ft3.add(ftL3);

		// Fast Food ....................
		ff = new JPanel();
		ff.setLayout(null);
		ff.setBounds(0,40,740,240);
		ff.setBackground(new Color(231, 231, 231));
		food.add(ff);

		p1 = new JPanel();
		p1.setLayout(null);
		p1.setBounds(15,15,160,200);
		p1.setBackground(Color.white);
		ff.add(p1);
			
		p11 = new JPanel();
		p11.setLayout(null);
		p11.setBounds(0,0,160,90);
		p1.add(p11);
		
		imL1 = new JLabel();
		imL1.setLayout(null);
		imL1.setBounds(0,0,160,90);
		imL1.setIcon(new ImageIcon(pizza));
		p11.add(imL1);
		
		foodL1 = new JLabel("Item : ");
		foodL1.setBounds(10,95,70,18);
		foodL1.setFont(font18);
		p1.add(foodL1);

		foodL11 = new JLabel("Pizza");
		foodL11.setBounds(70,95,75,18);
		foodL11.setFont(font18);
		p1.add(foodL11);
		
		prL1 = new JLabel("Price: ");
		prL1.setBounds(10,118,75,18);
		prL1.setFont(font18);
		p1.add(prL1);

		prL11 = new JLabel("350 TK");
		prL11.setBounds(70,118,75,18);
		prL11.setFont(font18);
		p1.add(prL11);
		
		qntL1 = new JLabel("Quantity: ");
		qntL1.setBounds(10,143,80,18);
		qntL1.setFont(font18);
		p1.add(qntL1);

		s1 = new JSpinner();
		s1.setBounds(90,142,45,18);
		p1.add(s1);
		
		b1 = new JButton("Add");
		b1.setBounds(25,165,100,30);
		b1.setBackground(new Color(255, 94, 94));
		b1.setForeground(Color.white);
		b1.setFont(font16);
		b1.setLayout(null);
		b1.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p1.add(b1);
		//------------------------------------
		p2 = new JPanel();
		p2.setLayout(null);
		p2.setBounds(190,15,160,200);
		p2.setBackground(Color.white);
		ff.add(p2);
			
		p22 = new JPanel();
		p22.setLayout(null);
		p22.setBounds(0,0,160,90);
		p2.add(p22);
		
		imL2 = new JLabel();
		imL2.setLayout(null);
		imL2.setBounds(0,0,160,90);
		imL2.setIcon(new ImageIcon(pasta));
		p22.add(imL2);
		
		foodL2 = new JLabel("Item : ");
		foodL2.setBounds(10,95,70,18);
		foodL2.setFont(font18);
		p2.add(foodL2);

		foodL22 = new JLabel("Pasta");
		foodL22.setBounds(70,95,75,18);
		foodL22.setFont(font18);
		p2.add(foodL22);
		
		prL2 = new JLabel("Price: ");
		prL2.setBounds(10,118,75,18);
		prL2.setFont(font18);
		p2.add(prL2);

		prL22 = new JLabel("300 TK");
		prL22.setBounds(70,118,75,18);
		prL22.setFont(font18);
		p2.add(prL22);
		
		qntL2 = new JLabel("Quantity: ");
		qntL2.setBounds(10,143,80,18);
		qntL2.setFont(font18);
		p2.add(qntL2);

		s2 = new JSpinner();
		s2.setBounds(90,142,45,18);
		p2.add(s2);
		
		b2 = new JButton("Add");
		b2.setBounds(25,165,100,30);
		b2.setBackground(new Color(255, 94, 94));
		b2.setForeground(Color.white);
		b2.setFont(font16);
		b2.setLayout(null);
		b2.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p2.add(b2);
		//-------------------------------------
		p3 = new JPanel();
		p3.setLayout(null);
		p3.setBounds(365,15,160,200);
		p3.setBackground(Color.white);
		ff.add(p3);
			
		p33 = new JPanel();
		p33.setLayout(null);
		p33.setBounds(0,0,160,90);
		p3.add(p33);
		
		imL3 = new JLabel();
		imL3.setLayout(null);
		imL3.setBounds(0,0,160,90);
		imL3.setIcon(new ImageIcon(burger));
		p33.add(imL3);
		
		foodL3 = new JLabel("Item : ");
		foodL3.setBounds(10,95,70,18);
		foodL3.setFont(font18);
		p3.add(foodL3);

		foodL33 = new JLabel("Burger");
		foodL33.setBounds(70,95,75,18);
		foodL33.setFont(font18);
		p3.add(foodL33);
		
		prL3 = new JLabel("Price: ");
		prL3.setBounds(10,118,75,18);
		prL3.setFont(font18);
		p3.add(prL3);

		prL33 = new JLabel("300 TK");
		prL33.setBounds(70,118,75,18);
		prL33.setFont(font18);
		p3.add(prL33);
		
		qntL3 = new JLabel("Quantity: ");
		qntL3.setBounds(10,143,80,18);
		qntL3.setFont(font18);
		p3.add(qntL3);

		s3 = new JSpinner();
		s3.setBounds(90,142,45,18);
		p3.add(s3);	
		
		b3 = new JButton("Add");
		b3.setBounds(25,165,100,30);
		b3.setBackground(new Color(255, 94, 94));
		b3.setForeground(Color.white);
		b3.setFont(font16);
		b3.setLayout(null);
		b3.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p3.add(b3);
		//-----------------------------------------
		p4 = new JPanel();
		p4.setLayout(null);
		p4.setBounds(540,15,160,200);
		p4.setBackground(Color.white);
		ff.add(p4);
			
		p44 = new JPanel();
		p44.setLayout(null);
		p44.setBounds(0,0,160,90);
		p4.add(p44);
		
		imL4 = new JLabel();
		imL4.setLayout(null);
		imL4.setBounds(0,0,160,90);
		imL4.setIcon(new ImageIcon(sandwich));
		p44.add(imL4);
	
		foodL4 = new JLabel("Item : ");
		foodL4.setBounds(10,95,70,18);
		foodL4.setFont(font18);
		p4.add(foodL4);

		foodL44 = new JLabel("Sandwich");
		foodL44.setBounds(70,95,75,18);
		foodL44.setFont(font18);
		p4.add(foodL44);
	
		prL4 = new JLabel("Price: ");
		prL4.setBounds(10,118,75,18);
		prL4.setFont(font18);
		p4.add(prL4);

		prL44 = new JLabel("250 TK");
		prL44.setBounds(70,118,75,18);
		prL44.setFont(font18);
		p4.add(prL44);
		
		qntL4 = new JLabel("Quantity: ");
		qntL4.setBounds(10,143,80,18);
		qntL4.setFont(font18);
		p4.add(qntL4);

		s4 = new JSpinner();
		s4.setBounds(90,142,45,18);
		p4.add(s4);
		
		b4 = new JButton("Add");
		b4.setBounds(25,165,100,30);
		b4.setBackground(new Color(255, 94, 94));
		b4.setForeground(Color.white);
		b4.setFont(font16);
		b4.setLayout(null);
		b4.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p4.add(b4);

		// Dessert .............
		dsrt = new JPanel();
		dsrt.setLayout(null);
		dsrt.setBounds(0,310,740,240);
		dsrt.setBackground(new Color(231, 231, 231));
		food.add(dsrt);

		p5 = new JPanel();
		p5.setLayout(null);
		p5.setBounds(15,15,160,200);
		p5.setBackground(Color.white);
		dsrt.add(p5);
			
		p55 = new JPanel();
		p55.setLayout(null);
		p55.setBounds(0,0,160,90);
		p5.add(p55);
		
		imL5 = new JLabel();
		imL5.setLayout(null);
		imL5.setBounds(0,0,160,90);
		imL5.setIcon(new ImageIcon(cake));
		p55.add(imL5);
	
		foodL5 = new JLabel("Item : ");
		foodL5.setBounds(10,95,70,18);
		foodL5.setFont(font18);
		p5.add(foodL5);

		foodL55 = new JLabel("Cake");
		foodL55.setBounds(70,95,75,18);
		foodL55.setFont(font18);
		p5.add(foodL55);
		
		prL5 = new JLabel("Price: ");
		prL5.setBounds(10,118,75,18);			prL5.setFont(font18);
		p5.add(prL5);

		prL55 = new JLabel("300 TK");
		prL55.setBounds(70,118,75,18);
		prL55.setFont(font18);
		p5.add(prL55);
	
		qntL5 = new JLabel("Quantity: ");
		qntL5.setBounds(10,143,80,18);
		qntL5.setFont(font18);
		p5.add(qntL5);

		s5 = new JSpinner();
		s5.setBounds(90,142,45,18);
		p5.add(s5);
	
		b5 = new JButton("Add");
		b5.setBounds(25,165,100,30);
		b5.setBackground(new Color(255, 94, 94));
		b5.setForeground(Color.white);
		b5.setFont(font16);
		b5.setLayout(null);
		b5.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p5.add(b5);
		//------------------------------------
		p6 = new JPanel();
		p6.setLayout(null);
		p6.setBounds(190,15,160,200);
		p6.setBackground(Color.white);
		dsrt.add(p6);
			
		p66 = new JPanel();
		p66.setLayout(null);
		p66.setBounds(0,0,160,90);
		p6.add(p66);
		
		imL6 = new JLabel();
		imL6.setLayout(null);
		imL6.setBounds(0,0,160,90);
		imL6.setIcon(new ImageIcon(iceCream));
		p66.add(imL6);
		
		foodL6 = new JLabel("Item : ");
		foodL6.setBounds(10,95,70,18);
		foodL6.setFont(font18);
		p6.add(foodL6);

		foodL66 = new JLabel("Ice Cream");
		foodL66.setBounds(70,95,75,18);
		foodL66.setFont(font18);
		p6.add(foodL66);
		
		prL6 = new JLabel("Price: ");
		prL6.setBounds(10,118,75,18);
		prL6.setFont(font18);
		p6.add(prL6);

		prL66 = new JLabel("250 TK");
		prL66.setBounds(70,118,75,18);
		prL66.setFont(font18);
		p6.add(prL66);
		
		qntL6 = new JLabel("Quantity: ");
		qntL6.setBounds(10,143,80,18);
		qntL6.setFont(font18);
		p6.add(qntL6);

		s6 = new JSpinner();
		s6.setBounds(90,142,45,18);
		p6.add(s6);
	
		b6 = new JButton("Add");
		b6.setBounds(25,165,100,30);
		b6.setBackground(new Color(255, 94, 94));
		b6.setForeground(Color.white);
		b6.setFont(font16);
		b6.setLayout(null);
		b6.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p6.add(b6);
		//-------------------------------------
		p7 = new JPanel();
		p7.setLayout(null);
		p7.setBounds(365,15,160,200);
		p7.setBackground(Color.white);
		dsrt.add(p7);
			
		p77 = new JPanel();
		p77.setLayout(null);
		p77.setBounds(0,0,160,90);
		p7.add(p77);
		
		imL7 = new JLabel();
		imL7.setLayout(null);
		imL7.setBounds(0,0,160,90);
		imL7.setIcon(new ImageIcon(waffles));
		p77.add(imL7);
		
		foodL7 = new JLabel("Item : ");
		foodL7.setBounds(10,95,70,18);
		foodL7.setFont(font18);
		p7.add(foodL7);

		foodL77 = new JLabel("Waffles");
		foodL77.setBounds(70,95,75,18);
		foodL77.setFont(font18);
		p7.add(foodL77);
		
		prL7 = new JLabel("Price: ");
		prL7.setBounds(10,118,75,18);
		prL7.setFont(font18);
		p7.add(prL7);

		prL77 = new JLabel("250 TK");
		prL77.setBounds(70,118,75,18);
		prL77.setFont(font18);
		p7.add(prL77);
	
		qntL7 = new JLabel("Quantity: ");
		qntL7.setBounds(10,143,80,18);
		qntL7.setFont(font18);
		p7.add(qntL7);

		s7 = new JSpinner();
		s7.setBounds(90,142,45,18);
		p7.add(s7);
		
		b7 = new JButton("Add");
		b7.setBounds(25,165,100,30);
		b7.setBackground(new Color(255, 94, 94));
		b7.setForeground(Color.white);
		b7.setFont(font16);
		b7.setLayout(null);
		b7.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p7.add(b7);

		// Drinks .............
		drn = new JPanel();
		drn.setLayout(null);
		drn.setBounds(0,580,740,240);
		drn.setBackground(new Color(231, 231, 231));
		food.add(drn);

		p8 = new JPanel();
		p8.setLayout(null);
		p8.setBounds(15,15,160,200);
		p8.setBackground(Color.white);
		drn.add(p8);
			
		p88 = new JPanel();
		p88.setLayout(null);
		p88.setBounds(0,0,160,90);
		p8.add(p88);
		
		imL8 = new JLabel();
		imL8.setLayout(null);
		imL8.setBounds(0,0,160,90);
		imL8.setIcon(new ImageIcon(mojo));
		p88.add(imL8);
		
		foodL8 = new JLabel("Item : ");
		foodL8.setBounds(10,95,70,18);
		foodL8.setFont(font18);
		p8.add(foodL8);

		foodL88 = new JLabel("Mojo");
		foodL88.setBounds(70,95,75,18);
		foodL88.setFont(font18);
		p8.add(foodL88);
		
		prL8 = new JLabel("Price: ");
		prL8.setBounds(10,118,75,18);
		prL8.setFont(font18);
		p8.add(prL8);

		prL88 = new JLabel("150 TK");
		prL88.setBounds(70,118,75,18);
		prL88.setFont(font18);
		p8.add(prL88);
		
		qntL8 = new JLabel("Quantity: ");
		qntL8.setBounds(10,143,80,18);
		qntL8.setFont(font18);
		p8.add(qntL8);

		s8 = new JSpinner();
		s8.setBounds(90,142,45,18);
		p8.add(s8);
		
		b8 = new JButton("Add");
		b8.setBounds(25,165,100,30);
		b8.setBackground(new Color(255, 94, 94));
		b8.setForeground(Color.white);
		b8.setFont(font16);
		b8.setLayout(null);
		b8.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p8.add(b8);
		//------------------------------------
		p9 = new JPanel();
		p9.setLayout(null);
		p9.setBounds(190,15,160,200);
		p9.setBackground(Color.white);
		drn.add(p9);
			
		p99 = new JPanel();
		p99.setLayout(null);
		p99.setBounds(0,0,160,90);
		p9.add(p99);
		
		imL9 = new JLabel();
		imL9.setLayout(null);
		imL9.setBounds(0,0,160,90);
		imL9.setIcon(new ImageIcon(rc));
		p99.add(imL9);
		
		foodL9 = new JLabel("Item : ");
		foodL9.setBounds(10,95,70,18);
		foodL9.setFont(font18);
		p9.add(foodL9);

		foodL99 = new JLabel("RC Cola");
		foodL99.setBounds(70,95,75,18);
		foodL99.setFont(font18);
		p9.add(foodL99);
		
		prL9 = new JLabel("Price: ");
		prL9.setBounds(10,118,75,18);
		prL9.setFont(font18);
		p9.add(prL9);

		prL99 = new JLabel("150 TK");
		prL99.setBounds(70,118,75,18);
		prL99.setFont(font18);
		p9.add(prL99);
		
		qntL9 = new JLabel("Quantity: ");
		qntL9.setBounds(10,143,80,18);
		qntL9.setFont(font18);
		p9.add(qntL9);

		s9 = new JSpinner();
		s9.setBounds(90,142,45,18);
		p9.add(s9);
		
		b9 = new JButton("Add");
		b9.setBounds(25,165,100,30);
		b9.setBackground(new Color(255, 94, 94));
		b9.setForeground(Color.white);
		b9.setFont(font16);
		b9.setLayout(null);
		b9.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p9.add(b9);
		//-------------------------------------
		p0 = new JPanel();
		p0.setLayout(null);
		p0.setBounds(365,15,160,200);
		p0.setBackground(Color.white);
		drn.add(p0);
			
		p00 = new JPanel();
		p00.setLayout(null);
		p00.setBounds(0,0,160,90);
		p0.add(p00);
		
		imL0 = new JLabel();
		imL0.setLayout(null);
		imL0.setBounds(0,0,160,90);
		imL0.setIcon(new ImageIcon(pepsi));
		p00.add(imL0);
		
		foodL0 = new JLabel("Item : ");
		foodL0.setBounds(10,95,70,18);
		foodL0.setFont(font18);
		p0.add(foodL0);

		foodL00 = new JLabel("Pepsi");
		foodL00.setBounds(70,95,75,18);
		foodL00.setFont(font18);
		p0.add(foodL00);
		
		prL0 = new JLabel("Price: ");
		prL0.setBounds(10,118,75,18);
		prL0.setFont(font18);
		p0.add(prL0);

		prL00 = new JLabel("150 TK");
		prL00.setBounds(70,118,75,18);
		prL00.setFont(font18);
		p0.add(prL00);
		
		qntL0 = new JLabel("Quantity: ");
		qntL0.setBounds(10,143,80,18);
		qntL0.setFont(font18);
		p0.add(qntL0);

		s0 = new JSpinner();
		s0.setBounds(90,142,45,18);
		p0.add(s0);
		
		b0 = new JButton("Add");
		b0.setBounds(25,165,100,30);
		b0.setBackground(new Color(255, 94, 94));
		b0.setForeground(Color.white);
		b0.setFont(font16);
		b0.setLayout(null);
		b0.setBorder(BorderFactory.createLineBorder(new Color(153, 125, 119),2));
		p0.add(b0);


		// Cart List ...................
		area = new JTextArea();
		area.setBounds(10,0,380,540);
		area.append("\n            --------------  Cart List  --------------\n\n   Food Item          Quantity           Price");
		area.setFont(font18);
		cart.add(area);

		// Button
		discountL = new JLabel("Cupon: ");
		discountL.setBounds(15, 17, 75 ,30);
		discountL.setFont(font20);
		btn.add(discountL);

		discountTF = new JTextField();
		discountTF.setBounds(100, 15, 100, 30);
		discountTF.setBorder(BorderFactory.createLineBorder(null));
		discountTF.setFont(font20);
		discountTF.setHorizontalAlignment(JTextField.CENTER);
		discountTF.setText("");
		btn.add(discountTF);

	 	discountB = new JButton("Apply");
		discountB.setBounds(220, 15, 90, 30);
		btn.add(discountB);

		totalL = new JLabel("Total: ");
		totalL.setBounds(20, 62, 75, 30);
		totalL.setFont(font20);
		btn.add(totalL);

		totalTF = new JTextField();
		totalTF.setBounds(100, 60, 100, 30);
		totalTF.setBorder(BorderFactory.createLineBorder(null));
		totalTF.setHorizontalAlignment(JTextField.CENTER);
		totalTF.setBackground(Color.white);
		totalTF.setFont(font16);
		totalTF.setEditable(false);
		totalTF.setText("");
		btn.add(totalTF);

		clearB = new JButton("Clear");
		clearB.setBounds(220, 60, 90, 30);
		btn.add(clearB);

		backB = new JButton("Back");
		backB.setBounds(30, 100, 90, 50);
		backB.setFont(font18);
		btn.add(backB);

		doneB = new JButton("Done");
		doneB.setBounds(220, 100, 90, 50);
		doneB.setFont(font16);
		btn.add(doneB);

		payB = new JButton("Pay");
		payB.setBounds(220, 100, 90, 50);
		payB.setFont(font16);
		btn.add(payB);
		
		offer1L = new JLabel("                              ! Offer !" );
		offer1L.setBounds(15, 170, 300, 20);
		offer1L.setFont(font20);
		btn.add(offer1L);

		offer1L = new JLabel("      Buy 3000 Tk And Get 10% Off !" );
		offer1L.setBounds(15, 190, 300, 20);
		offer1L.setFont(font18);
		btn.add(offer1L);

		offer1L = new JLabel("      Cupon: 3K10" );
		offer1L.setBounds(15, 210, 300, 20);
		offer1L.setFont(font18);
		btn.add(offer1L);



		// All Into This .............
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		b9.addActionListener(this);
		b0.addActionListener(this);
		discountB.addActionListener(this);
		clearB.addActionListener(this);
		backB.addActionListener(this);
		doneB.addActionListener(this);
		payB.addActionListener(this);

				
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == b1) {
			int amt = Integer.parseInt(s1.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL11.getText();
				float price = amt * 350.0f;
		     	area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL11.getText();
				float price = amt * 350.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b2) {
			int amt = Integer.parseInt(s2.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL22.getText();
				float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL22.getText();
				float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b3) {
			int amt = Integer.parseInt(s3.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL33.getText();
				float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL33.getText();
				float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b4) {
			int amt = Integer.parseInt(s4.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL44.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price  );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL44.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b5) {
			int amt = Integer.parseInt(s5.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL55.getText();
				float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL55.getText();
					float price = amt * 300.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b6) {
			int amt = Integer.parseInt(s6.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL66.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL66.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
				}
		}else if (ae.getSource() == b7) {
			int amt = Integer.parseInt(s7.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL77.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL77.getText();
				float price = amt * 250.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b8) {
			int amt = Integer.parseInt(s8.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL88.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL88.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
		}else if (ae.getSource() == b9) {
			int amt = Integer.parseInt(s9.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL99.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL99.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
				}
		}else if (ae.getSource() == b0) {
			int amt = Integer.parseInt(s0.getValue().toString());
			if (amt <= 0) {
				JOptionPane.showMessageDialog(this, "Quantity Must Be Greater Than Zero !!");
			} 
			else if (amt >=1 && amt<=9){
				String name = foodL00.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                   " + price );
				cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
			}
			else {
				String name = foodL00.getText();
				float price = amt * 150.0f;
				area.append("\n   " + cnt + ". " + name + "\t          " + amt + "                 " + price );					cnt++;
				total = total + price;
				String totalAm = Float.toString(total);
				totalTF.setText(totalAm);
				}
		}else if (ae.getSource() == clearB) {
			total = 0.0f;
			discount = 0.0f;
			s1.setValue(0);
			s2.setValue(0);
			s3.setValue(0);
			s4.setValue(0);
			s6.setValue(0);
			s7.setValue(0);
			s8.setValue(0);
			s9.setValue(0);
	
			cnt = 1;
	
			area.setText("\n            --------------  Cart List  --------------\n\n   Food Item          Quantity           Price");
	
			totalTF.setText("");

			btn.add(doneB);
			btn.remove(payB);
	
			discountB.setEnabled(true);
			discountTF.setText("");
			discountTF.setEditable(true);

		}else if (ae.getSource() == discountB) {
			String coupon = discountTF.getText();
			if (coupon.equals("3K10") && total>=3000) {
				discountTF.setEditable(false);
				discountB.setEnabled(false);
				discount = (total * 0.10f);
				String totalAm = Float.toString(total - discount);
				totalTF.setText(totalAm);
			} else {
				JOptionPane.showMessageDialog(this, "Coupon code is wrong! Try Again");
			}
		}else if (ae.getSource() == doneB) {
			btn.add(payB);
			btn.remove(doneB);
			area.append("\n   -----------------------------------------------------------------------------\n\n"
					+ "   Sub Total\t\t" + total + "\n" + "   Discount\t\t" + discount + " \n" + "   Total\t\t"
					+ (total - discount) + " Tk\n\n" + "                 Thank for being with us,\n                        Have a nice Day !");
		}else if (ae.getSource() == backB){
			RestaurantChoice f = new RestaurantChoice();
			this.setVisible(false);
			f.setVisible(true);
		}
		else if (ae.getSource() == payB){
			Payment f1 = new Payment();
			this.setVisible(false);
			f1.setVisible(true);
		}
	
	
		
	}
}



		



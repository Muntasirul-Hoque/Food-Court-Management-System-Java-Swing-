
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.JPasswordField.*;
 
public class RestaurantChoice extends JFrame implements ActionListener{
	JLabel ImageL,TitleL;
	JPanel MainP;
	JButton SunsetCafeB,BlueMoonB,OceanVillaB,TheMajesticB,BackB; 
	ImageIcon img;

	Font font40 = new Font("Candara",Font.BOLD,40);
    Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16); 

	
	public RestaurantChoice(){
		super(" Restaurant Choice  ");
		this.setSize(1188,850); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());

		// MAIN PANEL...................
		MainP = new JPanel();
		MainP.setBounds(0,0,1188,850);
		MainP.setLayout(null);
		MainP.setBackground(Color.white);
		this.add(MainP); 
		
		img = new ImageIcon("pic3.JPG");
		
		 //set for level
	    ImageL = new JLabel(img);
		ImageL.setSize(1188,850);
		MainP.add(ImageL);

		TitleL = new JLabel(" Choice Is Yours ");
		TitleL.setFont(font40);
		TitleL.setForeground(Color.BLACK);
		TitleL.setBounds(210,28,600,50);   
		TitleL.setVisible(true);
		ImageL.add(TitleL);
		
		
		SunsetCafeB = new JButton(" Sunset Cafe ");
		SunsetCafeB.setFont(font25);
		SunsetCafeB.setForeground(Color.black);
		SunsetCafeB.setBounds(280,200,220,50);
		SunsetCafeB.addActionListener(this);   
		ImageL.add(SunsetCafeB);

		BlueMoonB = new JButton(" Blue Moon ");
		BlueMoonB.setFont(font25);
		BlueMoonB.setForeground(Color.black);
		BlueMoonB.setBounds(280,270,220,50);
		BlueMoonB.addActionListener(this);   
		ImageL.add(BlueMoonB);
		
		OceanVillaB = new JButton(" Ocean Villa ");
		OceanVillaB.setFont(font25);
		OceanVillaB.setForeground(Color.black);
		OceanVillaB.setBounds(280,340,220,50);
		OceanVillaB.addActionListener(this);  
		MainP.add(OceanVillaB);
		
		TheMajesticB = new JButton(" The Majestic ");
		TheMajesticB.setFont(font25);
		TheMajesticB.setForeground(Color.black);
		TheMajesticB.setBounds(280,410,220,50);
		TheMajesticB.addActionListener(this);   
		ImageL.add(TheMajesticB);
		
		BackB = new JButton(" Back ");
		BackB.setBounds(50,750,120,30);
        BackB.setFont(font16);
		BackB.setBackground(Color.GRAY);
		BackB.addActionListener(this);
		ImageL.add(BackB);
		
	}
	public void actionPerformed(ActionEvent ae)  
		{
			if(ae.getSource()==SunsetCafeB)
			{
				Menu f = new Menu();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==BlueMoonB)
			{
				Menu f = new Menu();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==OceanVillaB)
			{
				Menu f = new Menu();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==TheMajesticB)
			{
				Menu f = new Menu();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==BackB)
			{
			UserLogin f = new UserLogin();
			this.setVisible(false);
            f.setVisible(true);
			}
		}
		
		
}
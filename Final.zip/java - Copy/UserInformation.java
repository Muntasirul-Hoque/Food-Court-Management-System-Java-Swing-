
import javax.swing.event.*;
import javax.print.attribute.standard.MediaSize.NA;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.table.DefaultTableModel;
import java.nio.file.*;
import java.util.*;

public class UserInformation extends JFrame implements ActionListener,MouseListener{
	private JPanel MainP;
	private JButton AddB,UpdateB,ClearB,BackB;
	private JLabel TitleL,IdL,NameL, NumberL,StatusL,AddressL,PassL;
	private JTable Table;
	private DefaultTableModel model;
	private JScrollPane scroll;
	private JTextField IdT,NameT,NumberT,AddressT,PassT;
	private JComboBox statusF;
	private String filename;
	private File file;
	private FileWriter writer;
	private String Id,Name,Number,Address,Pass,Staus,IdText;

	Font font40 = new Font("Candara",Font.BOLD,40);
    Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16); 
	
	public UserInformation(){

		
		this.setSize(1188,850);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setTitle("User Details");
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
		
		
		MainP = new JPanel();
		MainP.setLayout(null);
		MainP.setBounds(0,0,1188,850);
		MainP.setBackground(new Color(204, 202, 202));

		TitleL = new JLabel("User Details");
		TitleL.setBounds(450,30,500,50);
		TitleL.setFont(font40);
		MainP.add(TitleL);

		IdL = new JLabel("ID: ");
		IdL.setBounds(100,100,200,30);
		IdL.setFont(font16);
		MainP.add(IdL);
		
		int idnumber=1;
		try{
			BufferedReader br = new BufferedReader(new FileReader("user.txt"));
			String brline;
			while((brline=br.readLine())!=null){
				idnumber++;
			}
			br.close();
			IdText = Integer.toString(idnumber);
		}catch(Exception e){
			e.printStackTrace();
		}

		IdT = new JTextField();
		IdT.setEditable(true);
		IdT.setBounds(210,100,200,30);
		IdT.setText(IdText);
		IdT.setEditable(false);
		MainP.add(IdT);

		NameL = new JLabel("Full Name: ");
		NameL.setBounds(100,150,200,30);
		NameL.setFont(font16);
		MainP.add(NameL);

		NameT = new JTextField();
		NameT.setBounds(210,150,200,30);
		NameT.setText("");
		MainP.add(NameT);

		NumberL = new JLabel("Number: ");
		NumberL.setBounds(100,200,200,30);
		NumberL.setFont(font16);
		MainP.add(NumberL);

		NumberT = new JTextField();
		NumberT.setBounds(210,200,200,30);
		NumberT.setText("");
		MainP.add(NumberT);

		StatusL = new JLabel("Status: ");
		StatusL.setBounds(650,100,200,30);
		StatusL.setFont(font16);
		MainP.add(StatusL);


		String status[] = {"Status","Unblocked","Blocked"};
		statusF = new JComboBox(status);
		statusF.setBounds(760,100,200,30);
		MainP.add(statusF);

		AddressL = new JLabel("Address: ");
		AddressL.setBounds(650,150,200,30);
		AddressL.setFont(font16);
		MainP.add(AddressL);

		AddressT = new JTextField();
		AddressT.setBounds(760,150,200,30);
		AddressT.setText("");
		MainP.add(AddressT);
		
		PassL = new JLabel("Password: ");
		PassL.setBounds(650,200,200,30);
		PassL.setFont(font16);
		MainP.add(PassL);

		PassT = new JTextField();
		PassT.setBounds(760,200,200,30);
		PassT.setText("");
		MainP.add(PassT);
		
		AddB = new JButton("Add");
		AddB.setBounds(200,280,140,40);
		AddB.setBackground(new Color(0xFA5B39));
		AddB.setForeground(Color.white);
		AddB.setFont(font16);
		AddB.setBorder(null);
		MainP.add(AddB);
		
		UpdateB = new JButton("Update");
		UpdateB.setBounds(410,280,140,40);
		UpdateB.setBackground(new Color(0xFA5B39));
		UpdateB.setForeground(Color.white);
		UpdateB.setFont(font16);
		UpdateB.setBorder(null);
		MainP.add(UpdateB);
		
		ClearB = new JButton("Clear");
		ClearB.setBounds(620,280,140,40);
		ClearB.setBackground(new Color(0xFA5B39));
		ClearB.setForeground(Color.white);
		ClearB.setFont(font16);
		ClearB.setBorder(null);
		MainP.add(ClearB);
		
		BackB = new JButton("Back");
		BackB.setBounds(830,280,140,40);
		BackB.setBackground(new Color(0xFA5B39));
		BackB.setForeground(Color.white);
		BackB.setFont(font16);
		BackB.setBorder(null);
		MainP.add(BackB);
		
		
		
		
		model = new DefaultTableModel();
		String cols[] = {"ID","Name","Number","Status","Address","Password"};
		model.setColumnIdentifiers(cols);
		
		try{
			filename = "user.txt";
			file = new File(filename);
			BufferedReader bdr = new BufferedReader(new FileReader(file));
			String line;
			while((line = bdr.readLine())!=null){
				String Data[] = line.split(",");
				model.addRow(Data);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		Table = new JTable(model);
		Table.setFont(font16);
		Table.setSelectionBackground(new Color(0xFA5B39));
		Table.setBackground(new Color(0xffffff));
		Table.setRowHeight(30);
		scroll = new JScrollPane(Table);
        scroll.setBounds(25,350,1125,400);
		MainP.add(scroll);
		
		
		
		AddB.addActionListener(this);
		ClearB.addActionListener(this);
		BackB.addActionListener(this);
		UpdateB.addActionListener(this);
		Table.addMouseListener(this);
		this.add(MainP);
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent a){
		if(a.getSource()==ClearB){
			NameT.setText("");
			NumberT.setText("");
			statusF.setSelectedIndex(0);
			AddressT.setText("");
			PassT.setText("");
			IdT.setText(IdText);
		}else if(a.getSource()==UpdateB){
			if(Table.getSelectedRowCount()==1){
					Id = IdT.getText();
					Name = NameT.getText();
					Number = NumberT.getText();
					Staus = statusF.getSelectedItem().toString();
					Address = AddressT.getText();
					Pass = PassT.getText();
					
					model.setValueAt(Id,Table.getSelectedRow(),0);
					model.setValueAt(Name,Table.getSelectedRow(),1);
					model.setValueAt(Number,Table.getSelectedRow(),2);
					model.setValueAt(Staus,Table.getSelectedRow(),3);
					model.setValueAt(Address,Table.getSelectedRow(),4);
					model.setValueAt(Pass,Table.getSelectedRow(),5);
					
					JOptionPane.showMessageDialog(this,"Updated");
				}
					
				try{
					String mainfile = "user.txt";
					File main =  new File("user.txt");
					Id = IdT.getText();
					Name = NameT.getText();
					Number = NumberT.getText();
					Staus = statusF.getSelectedItem().toString();
					Address = AddressT.getText();
					Pass = PassT.getText();
					
					
					ArrayList<String> lines = new ArrayList<String>();
					BufferedReader mainrdr = new BufferedReader(new FileReader("user.txt"));
					String read;
					while((read=mainrdr.readLine())!=null){
						lines.add(read);
					}
					mainrdr.close();
					
					
					for (int i=0; i<lines.size();i++) {
						String[] data = lines.get(i).split(",");
						if (data[0].equals(Id)){
							lines.set(i, Id+","+Name+","+Number+","+Staus+","+Address+","+Pass);
							break;
						}
					}
					
					if(main.delete()){
						main.createNewFile();
						BufferedWriter mainbfw = new BufferedWriter(new FileWriter(main,true));
						//PrintWriter tempwtr = new PrintWriter(tempbfr);
						for (String line:lines){
							mainbfw.write(line);
							mainbfw.newLine();
						}
						mainbfw.close();
					}
				}
				catch(Exception e){
					e.printStackTrace();
				}
		}else if(a.getSource()==AddB){
			String ID = IdT.getText();
			String Name = NameT.getText();
			String Number = NumberT.getText();
			String Status = statusF.getSelectedItem().toString();
			String Address = AddressT.getText();
			String Pass = PassT.getText();

			
			
			try{
				BufferedWriter bufferwriter = new BufferedWriter(new FileWriter("user.txt",true));
				PrintWriter writer = new PrintWriter(bufferwriter);
				writer.println(ID+","+Name+","+Number+","+Staus+","+Address+","+Pass);
				writer.close();
				bufferwriter.close();
			}catch(Exception ex){
				JOptionPane.showMessageDialog(null,"File Found!! wr");
			}
			
			JOptionPane.showMessageDialog(null,"Data Added Successfully");
			
			String addRw[] = {ID,Name,Number,Status,Address,Pass};
			model.addRow(addRw);
		}else if(a.getSource()==BackB){
			Admin f = new Admin();
            this.setVisible(false);
            f.setVisible(true);
		}
	}
	public void mouseClicked(MouseEvent e) {
			if(e.getSource()==Table){
				String f1 = model.getValueAt(Table.getSelectedRow(),0).toString();
				String f2 = model.getValueAt(Table.getSelectedRow(),1).toString();
				String f3 = model.getValueAt(Table.getSelectedRow(),2).toString();
				String f4 = model.getValueAt(Table.getSelectedRow(),3).toString();
				String f5 = model.getValueAt(Table.getSelectedRow(),4).toString();
				String f6 = model.getValueAt(Table.getSelectedRow(),5).toString();

				
				IdT.setText(f1);
				NameT.setText(f2);
				NumberT.setText(f3);
				statusF.setSelectedItem(f4);
				AddressT.setText(f5);
				PassT.setText(f5);

			}
		}

		public void mousePressed(MouseEvent e) {
			
		}

		public void mouseReleased(MouseEvent e) {
			
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
		}
}

import javax.swing.*;

import java.awt.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.JPasswordField.*;

public class UserLogin extends JFrame implements ActionListener {
    JLabel ImageL, TitleL, NameL, PassL, RegistrationL;
    JTextField NameT;
	JPasswordField jp;
    JButton LoginB,RegistrationB,ExitB;
    JPanel MainP;
	ImageIcon img;

    // Font Set.............
    Font font40 = new Font("Candara",Font.BOLD,40);
    Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16); 

    public UserLogin() {

        super(" Login ");
        this.setSize(1188, 850);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null); 
        ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());

     
		// MAIN PANEL...................
		MainP = new JPanel();
		MainP.setBounds(0,0,1188,850);
		MainP.setLayout(null);
		MainP.setBackground(Color.white);
		this.add(MainP);
		
		img = new ImageIcon("pic2.JPG");
		
        ImageL = new JLabel(img);
        ImageL.setSize(1188,850);
		MainP.add(ImageL);

        TitleL = new JLabel("Log In Account");
        TitleL.setFont(font40);
        TitleL.setForeground(Color.black);
        TitleL.setBounds(230, 50, 350,50);
        ImageL.add(TitleL);

        NameL = new JLabel("User Name:");
        NameL.setFont(font25);
        NameL.setForeground(Color.white);
        NameL.setBounds(50, 200, 170, 25);
        ImageL.add(NameL);

        PassL = new JLabel("Password:");
        PassL.setFont(font25);
        PassL.setForeground(Color.white);
        PassL.setBounds(50, 275, 170, 25);
        ImageL.add(PassL);

        NameT = new JTextField(); // User Name
        NameT.setBounds(200, 200, 200, 35); 
        ImageL.add(NameT);

        jp = new JPasswordField();
        jp.setBounds(200, 275, 200, 35);
		jp.setEchoChar('*');
        ImageL.add(jp);

        LoginB = new JButton("Login");
        LoginB.setFont(font18);
        LoginB.setForeground(Color.black);
        LoginB.setBounds(200, 350, 150, 35);
        LoginB.addActionListener(this);
        ImageL.add(LoginB);

        RegistrationL = new JLabel("Don't have Account? Create a Account");
        RegistrationL.setBounds(150, 400, 400, 50);
        RegistrationL.setFont(font18);
        RegistrationL.setForeground(Color.white);
        ImageL.add(RegistrationL);
		
		RegistrationB = new JButton("Create Account");
        RegistrationB.setFont(font16);
        RegistrationB.setForeground(Color.black);
        RegistrationB.setBounds(200, 440, 150, 40);
        RegistrationB.addActionListener(this);
        ImageL.add(RegistrationB);

		ExitB = new JButton(" Exit ");
		ExitB.setBounds(50,750,120,30);
        ExitB.setFont(font16);
		ExitB.setBackground(Color.GRAY);
		ExitB.addActionListener(this);
		ImageL.add(ExitB);
    }
    private void setIcon(ImageIcon icon) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setIcon'");
    }
    public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == LoginB) 
        {
			String user = NameT.getText();
			String pass = jp.getText();
			
			try
            {
				File file = new File("user.txt");
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				String line;
				int valid=1; 

                if (user.equals("Admin") && pass.equals("5523")){
                    Admin f = new Admin();
					this.setVisible(false);
					f.setVisible(true);
                }
                else if (user.equals("Shop") && pass.equals("5523")){
                    ShopManager f = new ShopManager();
					this.setVisible(false);
					f.setVisible(true);
                }
                else {
                    while((line=br.readLine())!=null){
                        String data[] = line.split(",");
                    if(data[1].equals(user) && data[5].equals(pass)){
                        valid=1;
                        break;
                    }else{
                        valid=0;
                    }
                    }
                    if(valid==1){
                        RestaurantChoice f = new RestaurantChoice();
                        this.setVisible(false);
                        f.setVisible(true);
                    }else{
        
                        JOptionPane.showMessageDialog(this,"Wrong information!");
                    }
                }
			    
            }catch(Exception e){
                e.printStackTrace();
            }
        
        }
        
		
		else if (ae.getSource() == RegistrationB) {
			UserCreateAccount f = new UserCreateAccount();
				this.setVisible(false);
				f.setVisible(true);
          
        }
		else if (ae.getSource() == ExitB) {
            System.exit(0);
        }
	}
}

